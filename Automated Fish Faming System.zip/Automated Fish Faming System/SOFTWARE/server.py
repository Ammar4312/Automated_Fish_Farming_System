# server.py
from flask import Flask, jsonify, request
from flask_cors import CORS
import gspread
from google.oauth2.service_account import Credentials
from model import predict_next_week_health  # Import the ML model's prediction function

app = Flask(__name__)
CORS(app, origins=["http://127.0.0.1:5500"])

# Google Sheet Config
scope = ["https://spreadsheets.google.com/feeds", "https://www.googleapis.com/auth/drive"]
creds = Credentials.from_service_account_file("credentials.json", scopes=scope)
client = gspread.authorize(creds)
sheet = client.open_by_url(
    "https://docs.google.com/spreadsheets/d/1vVbGnCu5GAKw9lWU063HbhhVM5llis4hls90adh9SQk/edit?usp=sharing"
).sheet1

@app.route('/fetch', methods=['GET'])
def fetch_latest_sensor_data():
    data = sheet.get_all_values()
    values = data[1:]  # Skip header row

    if len(values) < 5:
        return jsonify({"error": "Not enough data (need last 5 days)"}), 400

    # Get the last 5 days of data and parse values as floats
    last_5_days = values[-5:]
    formatted_data = [[float(row[1]), float(row[2]), float(row[3])] for row in last_5_days]  # Temp, TDS, pH

    # Separate the data into individual lists: [temperatureList, phList, tdsList]
    temps = [row[0] for row in formatted_data]
    tds = [row[1] for row in formatted_data]
    phs = [row[2] for row in formatted_data]

    return jsonify({
        "data": [temps, phs, tds]
    })

@app.route('/predict', methods=['POST'])
def predict():
    try:
        input_data = request.get_json()

        # Extract temperature, ph, and tds values from the input
        last_5_days_data = [
            [float(input_data['temperature'][i]), float(input_data['ph'][i]), float(input_data['tds'][i])]
            for i in range(len(input_data['temperature']))
        ]

        # Predict using your trained ML model
        prediction = predict_next_week_health(last_5_days_data)

        # Returning the prediction and recommendation
        return jsonify({
            "next_7_days_growth": prediction["next_7_days_growth"],
            "recommendation": prediction["recommendation"]
        })

    except Exception as e:
        return jsonify({"error": str(e)}), 500

if __name__ == '__main__':
    app.run(debug=True)
