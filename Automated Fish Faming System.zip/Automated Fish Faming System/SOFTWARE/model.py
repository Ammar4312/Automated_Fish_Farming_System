import pandas as pd
import numpy as np
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report

# Load dataset
file_path = 'Datasets.csv'
data = pd.read_csv(file_path)

# Strip any potential whitespace from column names
data.columns = data.columns.str.strip()

# Print column names and check the first few rows
print("Columns in the dataset:", data.columns)
print("First few rows of the dataset:\n", data.head())

# Check for missing values and data types
print("Missing values in each column:\n", data.isna().sum())
print("Data types of each column:\n", data.dtypes)

# Handle missing values (you can choose to drop or fill them)
data = data.dropna()  # or use data.fillna(method='ffill')

# Features and target
X = data[['Temperature', 'TDS', 'pH']]  # Ensure column names match exactly
y = data['Growth_Status']  # Ensure this is the correct column name

# Check the data types of X and y
print("X data types:", X.dtypes)
print("y data type:", y.dtypes)

# Train/test split
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Train model
model = RandomForestClassifier(n_estimators=200, max_depth=15, min_samples_leaf=2, random_state=42)
model.fit(X_train, y_train)

# Optimal parameter ranges
optimal_ranges = {
    'Temperature': {'min': 25, 'max': 32},
    'pH': {'min': 6.5, 'max': 8.5},
    'TDS': {'min': 90, 'max': 250}
}

# Predict next 7 days condition based on last 5 days
def predict_next_week_health(last_5_days_data):
    growth_predictions = model.predict(last_5_days_data)
    
    temperatures = [row[0] for row in last_5_days_data]
    ph_values = [row[1] for row in last_5_days_data]
    tds_values = [row[2] for row in last_5_days_data]

    recommendation = []
    all_good = True

    # Check for parameter violations and make suggestions
    for param, values in zip(
        ['Temperature', 'pH', 'TDS'],
        [temperatures, ph_values, tds_values]
    ):
        for i, val in enumerate(values):
            if not (optimal_ranges[param]['min'] <= val <= optimal_ranges[param]['max']):
                all_good = False
                recommendation.append(
                    f"{param} on Day {i+1} is out of range (Value: {val}). Keep it between {optimal_ranges[param]['min']} and {optimal_ranges[param]['max']} to ensure optimal growth."
                )

    # Determine overall status
    if all(pred == 1 for pred in growth_predictions) and all_good:
        next_7_days_growth = "Healthy"
        recommendation = ["No adjustment needed. Conditions look good."]
    else:
        next_7_days_growth = "Unhealthy"
        if recommendation:
            recommendation.append("If you correct the above parameters, the environment should become healthy in the next 7 days.")

    return {
        "next_7_days_growth": next_7_days_growth,
        "recommendation": recommendation
    }
